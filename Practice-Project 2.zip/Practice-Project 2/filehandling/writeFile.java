package filehandling;

import java.io.FileWriter;
import java.io.IOException;

public class writeFile {

	public static void main(String[] args) {
		String data ="1, anirudh,tirupati ,AP";
		
		try {
			FileWriter output = new FileWriter("data.txt");
			output.write(data);
			System.out.println("Data is writted successfully");
			output.close();
		} catch (IOException e) {
			System.out.println("File write error....");
		}

	}

}


